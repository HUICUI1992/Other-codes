library(pheatmap)
source('CIBERSORT20210205.R')
mm_ID_transfer=read.table('mm_ensemblID2geneName.txt',sep='\t')
mm_ID_transfer=mm_ID_transfer[,c(1,2)]
colnames(mm_ID_transfer)=c('Gene.stable.ID','Gene.name')
exp=read.table('TPM.csv',sep=',',header=T)
meta=read.table('Meta.txt',sep='\t',header=T)

meta$Groups=paste(meta$Treatment,meta$Time,sep='.')
meta=meta[,c('Samples','Groups')]
colnames(meta)=c('ID','Groups')
colnames(exp)=gsub('.','-',colnames(exp),fixed = T)

rownames(exp)=exp[,1]
exp=exp[,-1]
comparsion=comparsion
dt1=meta
countData=exp[,dt1$ID]
countData$gene_ID=rownames(countData)
countData=merge(mm_ID_transfer,countData,by.y='gene_ID',by.x='Gene.stable.ID')
countData=aggregate(countData,by=list(countData$Gene.name),mean)
countData$Group.1=toupper(countData$Group.1)
countData=countData[,-c(2:3)]
write.table(countData,'gene_TPM.txt',sep='\t',quote=F,row.names = F)
re=CIBERSORT('LM22.txt','gene_TPM.txt')
re=data.frame(re)
re=re[,-c(23,24,25)]
re=t(re)
re=data.frame(re)
colnames(re)=gsub('.','-',colnames(re),fixed = T)
re_BD=re_BD[-c(1,18),]
pheatmap(re_BD,scale='row',gaps_col = c(3,6,9),cluster_rows = F,cluster_cols = F,color = colorRampPalette(c('red','white','green'))(100),main = 'Immune cell CIBERSORT')
