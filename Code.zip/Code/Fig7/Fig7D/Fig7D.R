library(ggplot2)
DEGs=function(comparsion){
  library(DESeq2)
  library(ggplot2)
  library(dplyr)
  mm_ID_transfer=read.table('mm_ensemblID2geneName.txt',sep='\t')
  mm_ID_transfer=mm_ID_transfer[,c(1,2)]
  colnames(mm_ID_transfer)=c('Gene.stable.ID','Gene.name')
  exp=read.table('count.csv',sep=',',header=T)
  meta=read.table('Meta.txt',sep='\t',header=T)
  meta$Groups=paste(meta$Treatment,meta$Time,sep='.')
  meta=meta[,c('Samples','Groups')]
  colnames(meta)=c('ID','Groups')
  colnames(exp)=gsub('.','-',colnames(exp),fixed = T)
  rownames(exp)=exp[,1]
  exp=exp[,-1]
  comparsion=comparsion
  dt1=meta[meta$Groups %in% comparsion,]
  condition=factor(dt1$Groups,levels=comparsion)
  colData=data.frame(row.names = dt1$ID,condition)
  need_samples=intersect(unlist(dt1$ID),unlist(colnames(exp)))
  countData=exp[,need_samples]
  colData=colData[need_samples,,drop=FALSE]
  condition=colData$condition
  countData=round(countData)
  countData[is.na(countData)]=0
  lowexp=apply(countData,1,mean)
  countData=countData[lowexp>1,]
  dds <- DESeqDataSetFromMatrix(countData, DataFrame(condition), design= ~ condition )
  head(dds)
  dds2=DESeq(dds)
  resultsNames(dds2)
  res <- results(dds2)
  summary(res)
  res <- res[order(res$padj),]
  all=subset(res)
  all=data.frame(all)
  all$gene_ID=rownames(all)
  all=merge(all,mm_ID_transfer,by.x='gene_ID',by.y='Gene.stable.ID')
  
  
  
  # ʾ�����ݣ�xΪlog2(FC)��yΪ-pvalue�Ķ���ֵ
  # ������ֵ
  pvalue_cutoff <- 0.05
  FC_cutoff <- 1
  
  # ������ֵ�����ݽ��з���
  all <- all %>%
    mutate(category = case_when(log2FoldChange >= FC_cutoff & padj <= pvalue_cutoff ~ "Upregulated",
                                log2FoldChange <= -FC_cutoff & padj <= pvalue_cutoff ~ "Downregulated",
                                TRUE ~ "Not changed"))
  all$category=factor(all$category,levels = c('Upregulated','Downregulated','Not changed'))
  upregulated <- nrow(subset(all, log2FoldChange > FC_cutoff & padj < pvalue_cutoff & Gene.name !='' ))
  downregulated <- nrow(subset(all, log2FoldChange < -FC_cutoff & padj < pvalue_cutoff & Gene.name !=''))
  # ���ƻ�ɽͼ
  p <- ggplot(all, aes(x = log2FoldChange, y = -log10(padj), color = category)) +
    geom_point() +
    scale_color_manual(values = c("green", "red", "gray")) +
    geom_hline(yintercept = -log10(pvalue_cutoff), color = "black", linetype = "dashed", size = 0.8) +
    geom_vline(xintercept = c(-FC_cutoff, FC_cutoff), color = "black", linetype = "dashed", size = 0.8) +
    labs(x = "log2(FC)", y = "-log10(adjust p-value)", color = "Category") +
    theme_bw()+theme(panel.grid =   element_blank(),legend.position = 'top',legend.title = element_blank())+
    annotate("text", x = Inf, y = Inf, label = paste("Upregulated:", upregulated), hjust = 1.2, vjust = 2, color = "green") +
    annotate("text", x = Inf, y = Inf, label = paste("Downregulated:", downregulated), hjust = 1.025, vjust = 3.5, color = "red")
  
  
  # ��ʾͼ��
  print(p)
  return(all)
}


comparsion=c('Vehicle.8','ISM033-154-BID+Cis.8')
res2.cis.033.BID.8=DEGs(comparsion)

K_gene_list=res2.cis.033.BID.8[order(res2.cis.033.BID.8$log2FoldChange,decreasing = T),]
fcs=as.vector(K_gene_list$log2FoldChange)
names(fcs)=as.vector(K_gene_list$Gene.name)

fcs=na.omit(fcs)
mhallmark=read.gmt('mh.all.v0.3.symbols.gmt')
gsea_re=GSEA(fcs,TERM2GENE = mhallmark,eps=0,pvalueCutoff = 1)
fig_data.cis.033.BID.8$ID=factor(fig_data.cis.033.BID.8$ID,levels = fig_data.cis.033.BID.8$ID[order(fig_data.cis.033.BID.8$NES)])
ggplot(data=fig_data.cis.033.BID.8[fig_data.cis.033.BID.8$p.adjust<0.05,],aes(x=ID,y=NES,fill=-log10(p.adjust)))+geom_bar(stat='identity')+scale_fill_gradient (low = "green", high = "darkgreen")+coord_flip()+theme_bw()

